"use strict";
/// <reference types="minecraft-scripting-types-server" />
Object.defineProperty(exports, "__esModule", { value: true });
// call test
require("./test");
// call examples
require("./examples");
// this program will die at './examples' module
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJpbmRleC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUEsMERBQTBEOztBQUUxRCxZQUFZO0FBQ1osa0JBQWdCO0FBRWhCLGdCQUFnQjtBQUNoQixzQkFBb0I7QUFFcEIsK0NBQStDIn0=