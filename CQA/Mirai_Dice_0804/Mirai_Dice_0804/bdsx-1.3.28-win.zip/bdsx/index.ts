/// <reference types="minecraft-scripting-types-server" />

// call test
import './test';

// call examples
import './examples';

// this program will die at './examples' module
